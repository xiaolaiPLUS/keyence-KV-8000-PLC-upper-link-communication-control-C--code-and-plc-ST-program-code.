# KeyenceComunication
基恩士PLC上位链路通讯协议
![image](https://user-images.githubusercontent.com/54002557/215701384-6643545c-d064-442b-96e7-ab41648ba118.png)
